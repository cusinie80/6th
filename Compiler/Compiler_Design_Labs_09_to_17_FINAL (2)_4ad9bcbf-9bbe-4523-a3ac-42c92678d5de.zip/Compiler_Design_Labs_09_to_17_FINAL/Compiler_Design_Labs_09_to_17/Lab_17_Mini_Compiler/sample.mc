int a, b, x;
float rate;
a = 10;
b = 20;
x = a + b * 2;
rate = x / 4;
print(x);
