int main() {
    int count;
    float total;
    count = 10;
    total = count * 2.5;
    return 0;
}
